var numero = Number(prompt('digite um número para achar seu valor elevado a 3:'))
console.log(numero * numero * numero)