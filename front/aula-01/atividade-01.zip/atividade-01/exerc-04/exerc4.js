var numero = Number(prompt('converter temperature em farenheit para celsius:'))
console.log((numero - 32) * 0.5556)