var nome = window.prompt('digite seu nome:')
var sobrenome = window.prompt('digite seu sobrenome:')
console.log(nome + ' ' + sobrenome)